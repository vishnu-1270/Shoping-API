package com.example.service;

import com.example.dto.AddToCartDTO;
import com.example.dto.CartDTO;
import com.example.dto.OrderDetailsDTO;
import com.example.dto.ProductDTO;
import com.example.entity.Cart;
import com.example.entity.OrderDetails;
import com.example.repository.CartRepository;
import com.example.repository.OrderDetailsRepository;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@Transactional
public class CartService {

    @Autowired
    CartRepository cartRepository;

    @Autowired
    OrderDetailsRepository orderDetailsRepository;

    @Autowired
    RestTemplate restTemplate;

    public CartDTO addItemsToCart(int customerId, AddToCartDTO addToCartDTO)
    {
        int discount,finalPrice;

        //finding requested item from ProductMS. Returning null if absent
        ProductDTO productDTO=restTemplate.getForObject("http://ProductMS/product/getProductById/"+addToCartDTO.getProductId(), ProductDTO.class);
            if(productDTO==null)
                return null;
        //Checking whether requested quantity is available.Returning null is not
        if(addToCartDTO.getQuantity()>productDTO.getQuantity())
            return null;

                //discount on requested product item
                finalPrice = productDTO.getPrice();
                LocalDateTime dateTime = LocalDateTime.now();
                if (productDTO.getDiscount() > 0 && dateTime.isAfter(productDTO.getDiscountFromDate())
                        && dateTime.isBefore(productDTO.getDiscountToDate()))
                {
                    discount = (int) ((productDTO.getDiscount() * finalPrice)/100);
                    finalPrice = finalPrice - discount;
                }

                //Requesting stored cart entity. Creating it if empty
                Cart cart=cartRepository.findByUserId(customerId);
                if(cart==null)
                {
                    cart = new Cart();
                    cart.setUserId(customerId);
                    cart.setOrderDetailsList(new ArrayList<>());
                }

                //Creating orderDetails object storing empty cart and saving to repo
                 OrderDetails orderDetails=new OrderDetails();
                 orderDetails.setCart(cart);
                 orderDetails.setPrice(finalPrice);
                 orderDetails.setProductId(productDTO.getId());
                 orderDetails.setQuantity(addToCartDTO.getQuantity());
                 orderDetails.setTotalPrice(finalPrice*addToCartDTO.getQuantity());
                 orderDetailsRepository.save(orderDetails);

                 cart.setTotalBill(cart.getTotalBill()+orderDetails.getTotalPrice());
                 cart.getOrderDetailsList().add(orderDetails);
                 cartRepository.save(cart);
                 return cartEntityToDTO(cart);
    }


    public CartDTO updateQuantity(int customerId, AddToCartDTO addToCartDTO)
    {
        Cart cart=cartRepository.findByUserId(customerId);

        //Checking if orderDetails is present with respect to productId and cartId
        Optional<OrderDetails> op=orderDetailsRepository.findByProductIdAndCart(addToCartDTO.getProductId(), cart);
        if(op.isEmpty())
            return null;

        //Checking whether quantity is 0
        if(addToCartDTO.getQuantity()==0)
        {
            cart.getOrderDetailsList().remove(op.get());
            orderDetailsRepository.delete(op.get());
            if(cart.getOrderDetailsList().size()==0)
            {
                cartRepository.delete(cart);
                return new CartDTO();
            }
            List<OrderDetails> list=orderDetailsRepository.findAllByCart(cart);
            int totalBIll=list.stream().map(p->p.getTotalPrice()).reduce(0,(s,p)->s+p);
            cart.setTotalBill(totalBIll);
            cart.setOrderDetailsList(list);
            cartRepository.save(cart);
            return cartEntityToDTO(cart);
        }

        //checking whether requested quantity is present
        ProductDTO productDTO=restTemplate.getForObject("http://ProductMS/product/getProductById/"+addToCartDTO.getProductId(), ProductDTO.class);
        if(productDTO.getQuantity()<addToCartDTO.getQuantity())
            return null;

        //updating orderDetails table
        OrderDetails orderDetails=op.get();
        orderDetails.setQuantity(addToCartDTO.getQuantity());
        orderDetails.setTotalPrice(orderDetails.getPrice()*orderDetails.getQuantity());
        orderDetailsRepository.save(orderDetails);

        //updating cart table
        List<OrderDetails> orderDetailsList=orderDetailsRepository.findAllByCart(cart);
        int totalBIll=orderDetailsList.stream().map(p->p.getTotalPrice()).reduce(0,(s,p)->s+p);
        cart.setTotalBill(totalBIll);
        cart.setOrderDetailsList(orderDetailsList);
        cartRepository.save(cart);
        return cartEntityToDTO(cart);
    }

    public CartDTO getCartItems(int customerId)
    {
        Cart cart=cartRepository.findByUserId(customerId);
        if(cart==null)
            return null;
        return cartEntityToDTO(cart);
    }

    public List<CartDTO> deleteAllByCustomer(int customerId)
    {
        //finding cart for specific the customerId
        Cart cart=cartRepository.findByUserId(customerId);
        if(cart==null)
            return null;
        //finding orderDetails for specific cart
        List<OrderDetails> orderDetailsList=orderDetailsRepository.findAllByCart(cart);
        //Deleting all orderDetails from the cart
        cart.getOrderDetailsList().removeAll(orderDetailsList);
        //Removing orderDetails of the specific cart
        orderDetailsRepository.deleteAll(orderDetailsList);
        //removing cart for the specific customerId
        cartRepository.delete(cart);

        //Getting all cart values
        List<Cart> cartList=cartRepository.findAll();
        if(cartList==null)
            return null;
        List<CartDTO> cartDTOS=new ArrayList<>();
        cartDTOS=cartList.stream().map(p->cartEntityToDTO(p)).collect(Collectors.toList());
        return cartDTOS;
    }
        public CartDTO cartEntityToDTO(Cart cart)
        {
            CartDTO cartDTO=new CartDTO();
            cartDTO.setUserId(cart.getUserId());
            cartDTO.setTotalBill(cart.getTotalBill());
            List<OrderDetailsDTO> orderDetailsDTOList=new ArrayList<>();
            for(OrderDetails i:cart.getOrderDetailsList())
            {
                OrderDetailsDTO orderDetailsDTO=new OrderDetailsDTO();
                orderDetailsDTO.setProductId(i.getProductId());
                orderDetailsDTO.setPrice(i.getPrice());
                orderDetailsDTO.setQuantity(i.getQuantity());
                orderDetailsDTO.setTotalPrice(i.getTotalPrice());
                orderDetailsDTOList.add(orderDetailsDTO);
            }
            cartDTO.setOrderDetailsDTOS(orderDetailsDTOList);
            return cartDTO;
    }
}

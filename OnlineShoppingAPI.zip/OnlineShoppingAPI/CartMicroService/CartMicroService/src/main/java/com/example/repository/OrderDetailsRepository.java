package com.example.repository;

import com.example.entity.Cart;
import com.example.entity.OrderDetails;
import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Optional;

public interface OrderDetailsRepository extends JpaRepository<OrderDetails,Integer> {
    public Optional<OrderDetails> findByProductIdAndCart(int productId, Cart cart);
    public List<OrderDetails> findAllByCart(Cart cart);
}

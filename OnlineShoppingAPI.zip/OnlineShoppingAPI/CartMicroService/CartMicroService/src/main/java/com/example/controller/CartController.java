package com.example.controller;

import com.example.dto.AddToCartDTO;
import com.example.dto.CartDTO;
import com.example.service.CartService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
@RequestMapping("cart")
public class CartController {

    @Autowired
    CartService cartService;

    @PostMapping("addItemsToCart/{customerId}")
    public ResponseEntity<CartDTO> addItemsToCart(@PathVariable int customerId,
                                                  @RequestBody AddToCartDTO addToCartDTO)
    {
        CartDTO cartDTO=cartService.addItemsToCart(customerId,addToCartDTO);
        if(cartDTO==null)
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        return new ResponseEntity<>(cartDTO,HttpStatus.OK);
    }

    @PutMapping("updateItems/{customerId}")
    public ResponseEntity<CartDTO> updateItems(@PathVariable int customerId, @RequestBody AddToCartDTO addToCartDTO)
    {
        CartDTO cartDTO=cartService.updateQuantity(customerId, addToCartDTO);
        if(cartDTO==null)
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        return new ResponseEntity<>(cartDTO,HttpStatus.OK);
    }

    @GetMapping("getCartItems/{customerId}")
    public ResponseEntity<CartDTO> getCartItems(@PathVariable int customerId)
    {
        CartDTO cartDTO=cartService.getCartItems(customerId);
        return new ResponseEntity<>(cartDTO,HttpStatus.OK);
    }

    @DeleteMapping("deleteAllByCustomerId/{customerId}")
    public ResponseEntity<List<CartDTO>> deleteAllByCustomerId(@PathVariable int customerId)
    {
            List<CartDTO> cartDTOList=cartService.deleteAllByCustomer(customerId);
            if(cartDTOList==null)
                return new ResponseEntity<>(HttpStatus.NOT_FOUND);
            return new ResponseEntity<>(cartDTOList,HttpStatus.OK);
    }

}

package com.example.dto;

import lombok.Data;

@Data
public class UpdateReviewDTO {
    private int reviewId;
    private String review;
}

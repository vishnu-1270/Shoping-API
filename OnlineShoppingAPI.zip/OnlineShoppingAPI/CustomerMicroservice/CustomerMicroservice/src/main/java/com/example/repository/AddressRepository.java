package com.example.repository;

import com.example.entity.Address;
import com.example.entity.Customer;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface AddressRepository extends JpaRepository<Address, Integer> {
    public List<Address> findAllByCustomer(Customer customer);
}

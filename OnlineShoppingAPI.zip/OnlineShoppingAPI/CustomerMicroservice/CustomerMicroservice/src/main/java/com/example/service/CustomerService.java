package com.example.service;

import com.example.dto.AddressDTO;
import com.example.dto.CustomerDTO;
import com.example.dto.LoginDTO;
import com.example.dto.ShowAddressesDTO;
import com.example.entity.Address;
import com.example.entity.Customer;
import com.example.repository.AddressRepository;
import com.example.repository.CustomerRepository;
import jakarta.transaction.Transactional;
import org.apache.catalina.filters.AddDefaultCharsetFilter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@Transactional
public class CustomerService {
    @Autowired
    CustomerRepository cr;

    @Autowired
    AddressRepository ar;

    public int login(LoginDTO loginDTO)
    {
        Optional<Customer> customer=cr.findByUsernameAndPassword(loginDTO.getUsername(), loginDTO.getPassword());
        if(customer.isEmpty())
            return 0;
        return customer.get().getCustomerId();
    }

    public CustomerDTO registerCustomer(CustomerDTO customerDTO)
    {
        Customer customer=new Customer();
        customer.setUsername(customerDTO.getUsername());
        customer.setPassword(customerDTO.getPassword());
        customer.setPhone(customerDTO.getPhone());
        customer.setEmail(customerDTO.getEmail());
        customer.setCustomerCreated(LocalDateTime.now());
        cr.save(customer);
        return customerEntityToDTO(customer);
    }

    public CustomerDTO getUserDetails(int userId)
    {
        Optional<Customer> customer=cr.findById(userId);
        if(customer.isEmpty())
            return null;
        return customerEntityToDTO(customer.get());
    }

    public List<CustomerDTO> getAllUsers()
    {
        List<Customer> customerList=cr.findAll();
        List<CustomerDTO> customerDTOList=customerList.stream().map(p->customerEntityToDTO(p)).collect(Collectors.toList());
        return customerDTOList;
    }
    public AddressDTO addAddress(AddressDTO addressDTO, int userId)
    {
        Optional<Customer> customer=cr.findById(userId);
        if(customer.isEmpty())
            return null;
        //adding address to address repo
        Address address=new Address();
        address.setAddress(addressDTO.getAddress());
        address.setCustomer(customer.get());
        ar.save(address);
        //updating address list of customer class and saving it to customer repo
        List<Address> addressList=customer.get().getAddresses();
        addressList.add(address);
        customer.get().setAddresses(addressList);
        cr.save(customer.get());
        //returning dto class
        AddressDTO dto=new AddressDTO();
        dto.setAddress(address.getAddress());
        return dto;
    }

    public CustomerDTO updateAddress(AddressDTO addressDTO,int userId,int addressId)
    {
        Optional<Address> op=ar.findById(addressId);
        if(op.isEmpty())
            return null;
        Address address=op.get();
        address.setAddress(addressDTO.getAddress());
        ar.save(address);
        //updating address list of customer class and saving it to cust. repo
        Customer customer=cr.findById(userId).get();
        List<Address> addressList=customer.getAddresses();
        for(Address i:addressList)
        {
            if(i.getAddressId()==addressId)
                i.setAddress(addressDTO.getAddress());
        }
        customer.setAddresses(addressList);
        cr.save(customer);
        return customerEntityToDTO(customer);
    }
    public CustomerDTO deleteAddress(int userId,int addressId)
    {
        //getting address by Id
        Optional<Address> op=ar.findById(addressId);
        if(op.isEmpty())
            return null;
        Address address=op.get();

        //deleting address 1rst from addresslist of customer table
        Customer customer=cr.findById(userId).get();
        List<Address> addressList=customer.getAddresses();
        addressList=addressList.stream().filter(p->p.getAddressId()!=addressId).collect(Collectors.toList());
        customer.setAddresses(addressList);
        cr.save(customer);

        //deleting address from address table
        ar.delete(address);
        return customerEntityToDTO(customer);
    }

    public List<ShowAddressesDTO> getAddressesByCustomerId(int customerId)
    {
        Customer customer=cr.findById(customerId).get();
        List<Address> address=ar.findAllByCustomer(customer);
        List<ShowAddressesDTO> showAddressesDTOS=new ArrayList<>();
        for(Address i:address)
        {
            ShowAddressesDTO showAddressesDTO=new ShowAddressesDTO();
            showAddressesDTO.setAddressId(i.getAddressId());
            showAddressesDTO.setDeliveryAddress(i.getAddress());
            showAddressesDTOS.add(showAddressesDTO);
        }
        return showAddressesDTOS;
    }

    public AddressDTO getAddressByAddressId(int addressId)
    {
        Address address=ar.findById(addressId).get();
        AddressDTO addressDTO=new AddressDTO();
        addressDTO.setAddress(address.getAddress());
        return addressDTO;
    }
    public CustomerDTO customerEntityToDTO(Customer customer)
    {
        CustomerDTO customerDTO=new CustomerDTO();
        customerDTO.setCustomerId(customer.getCustomerId());
        customerDTO.setUsername(customer.getUsername());
        customerDTO.setPassword(customer.getPassword());
        customerDTO.setPhone(customer.getPhone());
        customerDTO.setEmail(customer.getEmail());
        customerDTO.setCustomerCreated(customer.getCustomerCreated());

        List<Address> addressList=customer.getAddresses();
        List<AddressDTO> addressDTOList=new ArrayList<>();
        if(addressList==null)
            customerDTO.setAddresses(null);
        else {
            for (Address i : addressList) {
                AddressDTO x = new AddressDTO();
                x.setAddress(i.getAddress());
                addressDTOList.add(x);
            }
            customerDTO.setAddresses(addressDTOList);
        }
        return customerDTO;
    }
}

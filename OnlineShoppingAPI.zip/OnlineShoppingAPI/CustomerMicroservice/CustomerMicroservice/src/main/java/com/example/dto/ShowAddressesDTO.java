package com.example.dto;

import lombok.Data;

@Data
public class ShowAddressesDTO {
    private int addressId;
    private String deliveryAddress;
}

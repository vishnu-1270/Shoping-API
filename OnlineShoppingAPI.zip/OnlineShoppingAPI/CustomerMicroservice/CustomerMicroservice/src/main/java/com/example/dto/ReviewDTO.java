package com.example.dto;

import lombok.Data;

@Data
public class ReviewDTO {
    private int reviewId;
    private int userId;
    private int orderId;
    private int productId;
    private int rating;
    private String review;
}

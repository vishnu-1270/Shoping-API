package com.example.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;
@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Customer {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int customerId;

    @Column(name="usernames")
    private String username;

    @Column(name="passwords")
    private String password;
    private long phone;
    private String email;
    private LocalDateTime customerCreated;

    @OneToMany(cascade = CascadeType.ALL)
    private List<Address> addresses;
}

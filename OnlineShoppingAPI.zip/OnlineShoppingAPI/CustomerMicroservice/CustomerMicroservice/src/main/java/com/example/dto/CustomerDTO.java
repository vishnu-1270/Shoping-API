package com.example.dto;

import com.example.entity.Address;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.OneToMany;
import lombok.Data;

import java.time.LocalDateTime;
import java.util.List;
@Data
public class CustomerDTO {
    private int customerId;
    private String username;
    private String password;
    private long phone;
    private String email;
    private LocalDateTime customerCreated;
    private List<AddressDTO> addresses;
}

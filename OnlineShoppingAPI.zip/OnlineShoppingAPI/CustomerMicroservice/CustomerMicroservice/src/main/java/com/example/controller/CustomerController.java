package com.example.controller;

import com.example.dto.*;
import com.example.entity.Address;
import com.example.entity.Customer;
import com.example.service.CustomerService;
import org.apache.coyote.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import java.lang.reflect.Type;
import java.util.Arrays;
import java.util.List;

@RestController
@RequestMapping("customer")
public class CustomerController {

    @Autowired
    CustomerService cs;
    @Autowired
    RestTemplate restTemplate;
    static int userId;
    @PostMapping("register")
    public ResponseEntity<CustomerDTO> customerRegister(@RequestBody CustomerDTO customerDTO)
    {
        return new ResponseEntity<>(cs.registerCustomer(customerDTO), HttpStatus.OK);
    }

    @PostMapping("login")
    public ResponseEntity<String> login(@RequestBody LoginDTO loginDTO)
    {
        int res=cs.login(loginDTO);
        if(res==0)
            return new ResponseEntity<>("Invalid login credentials",HttpStatus.NOT_FOUND);
        userId=res;
        return new ResponseEntity<>("Login successful. Your userId:"+res, HttpStatus.OK);
    }

    @GetMapping("viewProfile")
    public ResponseEntity<CustomerDTO> viewProfile()
    {
        CustomerDTO customerDTO=cs.getUserDetails(userId);
        if(customerDTO==null)
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        return new ResponseEntity<>(customerDTO,HttpStatus.OK);
    }

    @GetMapping("getAllCustomers")
    public ResponseEntity<List<CustomerDTO>> getAllCustomers()
    {
        return new ResponseEntity<>(cs.getAllUsers(),HttpStatus.OK);
    }

    @GetMapping("getCustomerById/{id}")
    public ResponseEntity<CustomerDTO> getCustomerById(@PathVariable int id)
    {
        CustomerDTO customerDTO=cs.getUserDetails(id);
        if(customerDTO==null)
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        return new ResponseEntity<>(customerDTO,HttpStatus.OK);
    }

    @PostMapping("addAddress")
    public ResponseEntity<AddressDTO> addAddress(@RequestBody AddressDTO address)
    {
        return new ResponseEntity<>(cs.addAddress(address,userId),HttpStatus.OK);
    }

    @PutMapping("updateAddress/{addressId}")
    public ResponseEntity<CustomerDTO> updateAddress(@RequestBody AddressDTO addressDTO, @PathVariable int addressId)
    {
        CustomerDTO customerDTO=cs.updateAddress(addressDTO,userId,addressId);
        if(customerDTO==null)
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        return new ResponseEntity<>(customerDTO,HttpStatus.OK);
    }

    @DeleteMapping("deleteAddress/{addressId}")
    public ResponseEntity<CustomerDTO> deleteCustomer(@PathVariable int addressId)
    {
        CustomerDTO customerDTO=cs.deleteAddress(userId,addressId);
        if(customerDTO==null)
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        return new ResponseEntity<>(customerDTO,HttpStatus.OK);
    }

    @GetMapping("getAllAddressesForLoggedInCustomer")
    public ResponseEntity<List<ShowAddressesDTO>> getAllAddressesForCustomerId()
    {
            return new ResponseEntity<>(cs.getAddressesByCustomerId(userId),HttpStatus.OK);
    }

    @GetMapping("getAddressByAddressId/{addressId}")
    public ResponseEntity<AddressDTO> getAddressByAddressId(@PathVariable int addressId)
    {
        return new ResponseEntity<>(cs.getAddressByAddressId(addressId),HttpStatus.OK);
    }

    @GetMapping("viewAllProducts")
    public ResponseEntity<List<ProductDTO>> viewAllProducts()
    {
        ProductDTO arr[]=restTemplate.getForObject("http://ProductMS/product/getAllProducts",ProductDTO[].class);
        List<ProductDTO> productDTOS= Arrays.asList(arr);
        return new ResponseEntity<>(productDTOS,HttpStatus.OK);
    }

    @GetMapping("viewAllCategories")
    public ResponseEntity<List<CategoriesDTO>> viewAllCategories()
    {
        CategoriesDTO categories[]=restTemplate.getForObject("http://ProductMS/product/getAllCategories",CategoriesDTO[].class);
        List<CategoriesDTO> categoriesDTOS=Arrays.asList(categories);
        return new ResponseEntity<>(categoriesDTOS,HttpStatus.OK);
    }

    @GetMapping("viewProductsByCategory/{categoryName}")
    public ResponseEntity<List<ProductDTO>> viewProductsByCategory(@PathVariable String categoryName)
    {
        ParameterizedTypeReference<List<ProductDTO>> response=new ParameterizedTypeReference<List<ProductDTO>>() {
        };
        ResponseEntity<List<ProductDTO>> responseType=restTemplate.exchange("http://ProductMS/product/getProductsByCategory/"+categoryName,HttpMethod.GET,null,response);
        return responseType;
    }
    @GetMapping("getProductById/{productID}")
    public ResponseEntity<ProductDTO> getProductById(@PathVariable int productId)
    {
        return new ResponseEntity<>(restTemplate.getForObject("http://ProductMS/product/getProductById/"+productId,ProductDTO.class),HttpStatus.OK);
    }

    @GetMapping("getReviewsByProductId/{productId}")
    public ResponseEntity<List<ShowReview>> getReviews(@PathVariable int productId)
    {
        ParameterizedTypeReference<List<ShowReview>> reference=new ParameterizedTypeReference<List<ShowReview>>() {
        };
        ResponseEntity<List<ShowReview>> showReviewList=restTemplate.exchange("http://ReviewMS/review/getReviewsByProductId/"+productId,HttpMethod.GET,null,reference);
        return showReviewList;
    }

    @GetMapping("searchProduct/{search}")
    public ResponseEntity<List<ProductDTO>> searchProduct(@PathVariable String search)
    {
        ProductDTO arr[]=restTemplate.getForObject("http://ProductMS/product/searchProduct/"+search,ProductDTO[].class);
        List<ProductDTO> productDTOList=Arrays.asList(arr);
        return new ResponseEntity<>(productDTOList,HttpStatus.OK);
    }

    @GetMapping("searchProductPriceLowToHigh/{search}")
    public ResponseEntity<List<ProductDTO>> searchProductAscendingPrice(@PathVariable String search)
    {
        ProductDTO arr[]=restTemplate.getForObject("http://ProductMS/product/searchProductPriceLowToHigh/"+search,ProductDTO[].class);
        List<ProductDTO> productDTOList=Arrays.asList(arr);
        return new ResponseEntity<>(productDTOList,HttpStatus.OK);
    }

    @GetMapping("searchProductPriceHighToLow/{search}")
    public ResponseEntity<List<ProductDTO>> searchProductDescendingPrice(@PathVariable String search)
    {
        ProductDTO arr[]=restTemplate.getForObject("http://ProductMS/product/searchProductPriceHighToLow/"+search,ProductDTO[].class);
        List<ProductDTO> productDTOList=Arrays.asList(arr);
        return new ResponseEntity<>(productDTOList,HttpStatus.OK);
    }

    @GetMapping("searchProductSortByRating/{search}")
    public ResponseEntity<List<ProductDTO>> searchProductSortByRating(@PathVariable String search)
    {
        ProductDTO arr[]=restTemplate.getForObject("http://ProductMS/product/searchProductSortByRating/"+search,ProductDTO[].class);
        List<ProductDTO> productDTOList=Arrays.asList(arr);
        return new ResponseEntity<>(productDTOList,HttpStatus.OK);
    }

    @GetMapping("searchProductSortByAvailability/{search}")
    public ResponseEntity<List<ProductDTO>> searchProductSortByAvailability(@PathVariable String search)
    {
        ProductDTO arr[]=restTemplate.getForObject("http://ProductMS/product/searchProductSortByAvailability/"+search,ProductDTO[].class);
        List<ProductDTO> productDTOList=Arrays.asList(arr);
        return new ResponseEntity<>(productDTOList,HttpStatus.OK);
    }

    @GetMapping("searchProductSortByDiscount/{search}")
    public ResponseEntity<List<ProductDTO>> searchProductSortByDiscount(@PathVariable String search)
    {
        ProductDTO arr[]=restTemplate.getForObject("http://ProductMS/product/searchProductSortByDiscount/"+search,ProductDTO[].class);
        List<ProductDTO> productDTOList=Arrays.asList(arr);
        return new ResponseEntity<>(productDTOList,HttpStatus.OK);
    }

    @GetMapping("discountsForTheDay")
    public ResponseEntity<List<ProductDTO>> discountForTheDay()
    {
        ProductDTO arr[]=restTemplate.getForObject("http://ProductMS/product/discountsForTheDay",ProductDTO[].class);
        List<ProductDTO> productDTOList=Arrays.asList(arr);
        return new ResponseEntity<>(productDTOList,HttpStatus.OK);
    }

    @PostMapping("addItemToCart")
    public ResponseEntity<CartDTO> addItemToCart(@RequestBody AddToCartDTO addToCartDTO)
    {
        CartDTO cartDTO=restTemplate.postForObject("http://CartMS/cart/addItemsToCart/"+userId,addToCartDTO,CartDTO.class);
        if(cartDTO==null)
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        return new ResponseEntity<>(cartDTO,HttpStatus.OK);
    }

    @PutMapping("updateCartItem")
    public ResponseEntity<CartDTO> updateItem(@RequestBody AddToCartDTO addToCartDTO)
    {
        HttpHeaders headers=new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<AddToCartDTO> requestEntity=new HttpEntity<>(addToCartDTO,headers);
        ResponseEntity<CartDTO> response=restTemplate.exchange("http://CartMS/cart/updateItems/"+userId,HttpMethod.PUT,requestEntity,CartDTO.class);
        return response;
    }

    @GetMapping("viewCartItems")
    public ResponseEntity<CartDTO> viewCartItems()
    {
        CartDTO cartDTO=restTemplate.getForObject("http://CartMS/cart/getCartItems/"+userId,CartDTO.class);
        return new ResponseEntity<>(cartDTO,HttpStatus.OK);
    }

    @PostMapping("placeOrder/{addressId}")
    public ResponseEntity<OrderDTO> placeOrder(@PathVariable int addressId)
    {
        OrderDTO orderDTO=restTemplate.postForObject("http://OrderMS/order/placeOrder/"+userId+"/"+addressId,null,OrderDTO.class);
        return new ResponseEntity<>(orderDTO,HttpStatus.OK);
    }

    @GetMapping("getOrderByOrderId/{orderId}")
    public ResponseEntity<OrderDTO> getOrderByOrderId(@PathVariable int orderId)
    {
        OrderDTO orderDTO=restTemplate.getForObject("http://OrderMS/order/getOrderByOrderId/"+orderId,OrderDTO.class);
        return new ResponseEntity<>(orderDTO,HttpStatus.OK);
    }

    @GetMapping("viewAllOrders")
    public ResponseEntity<List<OrderDTO>> viewAllOrders()
    {
        OrderDTO orders[]=restTemplate.getForObject("http://OrderMS/order/viewAllOrdersForSpecificCustomer/"+userId,OrderDTO[].class);
        List<OrderDTO> orderDTOList=Arrays.asList(orders);
        return new ResponseEntity<>(orderDTOList,HttpStatus.OK);
    }

    @PutMapping("updateAddressForSpecificOrder/{orderId}/{addressId}")
    public ResponseEntity<OrderDTO> updateAddressForOrder(@PathVariable int orderId,@PathVariable int addressId)
    {
        HttpHeaders headers=new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        ResponseEntity<OrderDTO> response=restTemplate.exchange("http://OrderMS/order/updateAddressForSpecificOrder/"+orderId+"/"+addressId,HttpMethod.PUT,null,OrderDTO.class);
        return response;
    }

    @PostMapping("addRatingAndReview")
    public ResponseEntity<ReviewDTO> addRatingAndReview(@RequestBody ReviewDTO reviewDTO)
    {
        ResponseEntity<ReviewDTO> response=restTemplate.postForEntity("http://ReviewMS/review/addRatingAndReview",reviewDTO,ReviewDTO.class);
        return response;
    }

    @PutMapping("updateReview")
    public ResponseEntity<ReviewDTO> updateReview(@RequestBody UpdateReviewDTO updateReviewDTO)
    {
        HttpHeaders headers=new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<UpdateReviewDTO> httpEntity=new HttpEntity<>(updateReviewDTO,headers);
        ResponseEntity<ReviewDTO> response=restTemplate.exchange("http://ReviewMS/review/updateReview",HttpMethod.PUT,httpEntity,ReviewDTO.class);
        return response;
    }

    @DeleteMapping("deleteReview/{reviewId}")
    public ResponseEntity<List<ShowReview>> deleteReview(@PathVariable int reviewId)
    {
        ParameterizedTypeReference<List<ShowReview>> reference=new ParameterizedTypeReference<List<ShowReview>>() {
        };
        ResponseEntity<List<ShowReview>> response=restTemplate.exchange("http://ReviewMS/review/deleteReview/"+reviewId,HttpMethod.DELETE,null,reference);
        return response;
    }

    @GetMapping("logout")
    public ResponseEntity<String> logout()
    {
        userId=0;
        return new ResponseEntity<>("User logged out",HttpStatus.OK);
    }
}

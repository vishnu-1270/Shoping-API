package com.example.dto;
import lombok.Data;
import java.time.LocalDateTime;
import java.util.List;

@Data
public class OrderDTO {
    private int orderId;
    private int userId;
    private int billTotal;
    private String deliveryAddress;
    private LocalDateTime orderDate;
    private String deliveryStatus;
    private List<OrderedItemsDTO> orderDetailsDTOS;
}

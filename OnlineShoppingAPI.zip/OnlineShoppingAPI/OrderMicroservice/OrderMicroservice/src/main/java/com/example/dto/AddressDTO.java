package com.example.dto;

import lombok.Data;

@Data
public class AddressDTO {
    public String address;
}

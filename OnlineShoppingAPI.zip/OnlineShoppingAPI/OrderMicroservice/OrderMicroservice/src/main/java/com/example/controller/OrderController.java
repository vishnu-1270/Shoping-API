package com.example.controller;

import com.example.dto.MonthlySaleDTO;
import com.example.dto.OrderDTO;
import com.example.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("order")
public class OrderController {

    @Autowired
    OrderService orderService;

    @PostMapping("placeOrder/{customerId}/{addressId}")
    public ResponseEntity<OrderDTO> placeOrder(@PathVariable int customerId, @PathVariable int addressId)
    {
        OrderDTO orderDTO=orderService.placeOrder(customerId,addressId);
        if(orderDTO==null)
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        return new ResponseEntity<>(orderDTO,HttpStatus.OK);
    }

    @GetMapping("getOrderByOrderId/{orderId}")
    public ResponseEntity<OrderDTO> getOrderByOrderId(@PathVariable int orderId)
    {
        OrderDTO orderDTO=orderService.getOrderByOrderId(orderId);
        if(orderDTO==null)
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        return new ResponseEntity<>(orderDTO,HttpStatus.OK);
    }

    @GetMapping("getAllPlacedOrders")
    public ResponseEntity<List<OrderDTO>> getAllOrders()
    {
        return new ResponseEntity<>(orderService.getAllOrders(),HttpStatus.OK);
    }

    @GetMapping("getAllDeliveredOrders")
    public ResponseEntity<List<OrderDTO>> getAllDeliveredOrders()
    {
        return new ResponseEntity<>(orderService.getAllDelivered(),HttpStatus.OK);
    }

    @GetMapping("viewAllOrdersForSpecificCustomer/{customerId}")
    public ResponseEntity<List<OrderDTO>> viewAllOrdersForSpecificCustomer(@PathVariable int customerId)
    {
        return new ResponseEntity<>(orderService.viewAllOrdersForSpecificCustomer(customerId),HttpStatus.OK);
    }

    @PutMapping("updateAddressForSpecificOrder/{orderId}/{addressId}")
    public ResponseEntity<OrderDTO> updateAddressForSpecificOrder(@PathVariable int orderId, @PathVariable int addressId)
    {
        return new ResponseEntity<>(orderService.updateAddressForSpecificOrder(addressId,orderId),HttpStatus.OK);
    }

    @GetMapping("viewAllOrdersForSpecificDate/{date}")
    public ResponseEntity<List<OrderDTO>> viewAllOrdersForSpecificDate(@PathVariable LocalDate date)
    {
        List<OrderDTO> orderDTOList=orderService.viewAllOrdersForSpecificDate(date);
        if(orderDTOList.isEmpty())
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        return new ResponseEntity<>(orderDTOList,HttpStatus.OK);
    }

    @GetMapping("viewSaleForSpecificMonth/{month}")
    public ResponseEntity<MonthlySaleDTO> viewSaleForSpecificMonth(@PathVariable String month)
    {
        MonthlySaleDTO monthlySaleDTO=orderService.viewSaleForSpecificMonth(month);
        if(monthlySaleDTO==null)
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        return new ResponseEntity<>(monthlySaleDTO,HttpStatus.OK);
    }

    @PutMapping("updateDeliveryStatusForSpecificOrder/{orderId}/{status}")
    public ResponseEntity<OrderDTO> updateDeliveryStatusForSpecificOrder(@PathVariable int orderId,
                                                                         @PathVariable String status)
    {
        return new ResponseEntity<>(orderService.updateDeliveryStatus(orderId,status),HttpStatus.OK);
    }

}

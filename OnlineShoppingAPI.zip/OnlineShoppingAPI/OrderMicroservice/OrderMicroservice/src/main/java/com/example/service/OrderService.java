package com.example.service;

import com.example.dto.*;
import com.example.entity.Order;
import com.example.entity.OrderedItems;
import com.example.repository.OrderRepository;
import com.example.repository.OrderedItemsRepository;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.amqp.RabbitConnectionDetails;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@Transactional
public class OrderService {

    @Autowired
    OrderRepository orderRepository;

    @Autowired
    OrderedItemsRepository orderedItemsRepository;

    @Autowired
    RestTemplate restTemplate;

    public OrderDTO placeOrder(int customerId, int addressId)
    {
        AddressDTO addressDTO=restTemplate.getForObject("http://CustomerMS/customer/getAddressByAddressId/"+addressId, AddressDTO.class);
        if(addressDTO==null)
            return null;
        CartDTO cartDTO=restTemplate.getForObject("http://CartMS/cart/getCartItems/"+customerId,CartDTO.class);

        //Creating order object
        Order order=new Order();
        order.setOrderDate(LocalDateTime.now());
        order.setBillTotal(cartDTO.getTotalBill());
        order.setUserId(cartDTO.getUserId());
        order.setDeliveryStatus("order placed");
        order.setDeliveryAddress(addressDTO.getAddress());
        order.setOrderedItems(new ArrayList<>());

        //Creating orderedItems object
        for(OrderDetailsDTO i:cartDTO.getOrderDetailsDTOS())
        {
            OrderedItems orderedItems=new OrderedItems();
            orderedItems.setOrder(order);
            orderedItems.setPrice(i.getPrice());
            orderedItems.setProductId(i.getProductId());
            orderedItems.setQuantity(i.getQuantity());
            orderedItems.setTotalPrice(i.getTotalPrice());
            order.getOrderedItems().add(orderedItems);
            orderedItemsRepository.save(orderedItems);
        }
        orderRepository.save(order);

        //Deleting cart row for this customerId
        restTemplate.delete("http://CartMS/cart/deleteAllByCustomerId/"+customerId);

        //Updating quantity one by one at Product table
        for(OrderDetailsDTO i:cartDTO.getOrderDetailsDTOS())
        {
            ProductDTO productDTO=restTemplate.getForObject("http://ProductMS/product/getProductById/"+i.getProductId(),ProductDTO.class);
            productDTO.setQuantity(productDTO.getQuantity()-i.getQuantity());
            HttpHeaders headers=new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            HttpEntity<ProductDTO> requestEntity=new HttpEntity<>(productDTO,headers);
            restTemplate.exchange("http://ProductMS/product/updateProduct/"+productDTO.getId(), HttpMethod.PUT,requestEntity,ProductDTO.class);
        }
        return orderEntityToDTO(order);
    }

    public List<OrderDTO> viewAllOrdersForSpecificCustomer(int customerId)
    {
        List<Order> orderList=orderRepository.findByUserId(customerId);
        List<OrderDTO> orderDTOList=new ArrayList<>();
        orderDTOList=orderList.stream().map(p->orderEntityToDTO(p)).collect(Collectors.toList());
        return orderDTOList;
    }

    public OrderDTO updateAddressForSpecificOrder(int addressId,int orderId)
    {
        AddressDTO addressDTO=restTemplate.getForObject("http://CustomerMS/customer/getAddressByAddressId/"+addressId, AddressDTO.class);
        Order order=orderRepository.findById(orderId).get();
        order.setDeliveryAddress(addressDTO.getAddress());
        orderRepository.save(order);
        return orderEntityToDTO(order);
    }

    public List<OrderDTO> viewAllOrdersForSpecificDate(LocalDate date)
    {
        List<Order> orderList=orderRepository.findAll();
        List<OrderDTO> orderDTOList=new ArrayList<>();
        for(Order i:orderList)
        {
            if(i.getOrderDate().toString().substring(0,10).equals(date.toString()))
            {
                OrderDTO orderDTO=orderEntityToDTO(i);
                orderDTOList.add(orderDTO);
            }
        }
        return orderDTOList;
    }

    public MonthlySaleDTO viewSaleForSpecificMonth(String month)
    {
        int monthNumber=0,totalSale=0;
        List<String> monthList= Arrays.asList("january","february","march","april","may","june",
                "july","august","september","october","november","december");
        for(int i=0;i<monthList.size();i++) {
            if (monthList.get(i).startsWith(month.toLowerCase())) {
                monthNumber = i + 1;
                break;
            }
        }
        if(monthNumber==0)
            return null;
        String monthString=Integer.toString(monthNumber);
        if(monthString.length()==1)
            monthString="0"+monthString;
        List<Order> allOrders=orderRepository.findAll();
        for(Order i:allOrders)
        {
            if(i.getOrderDate().toString().substring(5,7).equals(monthString))
                totalSale=totalSale+i.getBillTotal();
        }
        MonthlySaleDTO monthlySaleDTO=new MonthlySaleDTO();
        monthlySaleDTO.setMonth(month);
        monthlySaleDTO.setTotalSale(totalSale);
        return monthlySaleDTO;
    }

    public OrderDTO updateDeliveryStatus(int orderId,String status)
    {
        Order order=orderRepository.findById(orderId).get();
        order.setDeliveryStatus(status);
        orderRepository.save(order);
        return orderEntityToDTO(order);
    }

    public OrderDTO getOrderByOrderId(int orderId)
    {
        Optional<Order> op=orderRepository.findById(orderId);
        if(op.isEmpty())
            return null;
        return orderEntityToDTO(op.get());
    }

    public List<OrderDTO> getAllOrders()
    {
        List<Order> orderList=orderRepository.findAll();
        List<OrderDTO> orderDTOList=orderList.stream().map(p->orderEntityToDTO(p)).collect(Collectors.toList());
        return orderDTOList;
    }

    public List<OrderDTO> getAllDelivered()
    {
        List<Order> orderList=orderRepository.findAll();
        List<OrderDTO> orderDTOList=orderList.stream().filter(p->p.getDeliveryStatus().equalsIgnoreCase("delivered"))
                .map(p->orderEntityToDTO(p)).collect(Collectors.toList());
        return orderDTOList;
    }

    public OrderDTO orderEntityToDTO(Order order)
    {
        OrderDTO orderDTO=new OrderDTO();
        orderDTO.setOrderId(order.getOrderId());
        List<OrderedItemsDTO> list=new ArrayList<>();
        for(OrderedItems i:order.getOrderedItems())
        {
            OrderedItemsDTO orderedItemsDTO=new OrderedItemsDTO();
            orderedItemsDTO.setPrice(i.getPrice());
            orderedItemsDTO.setProductId(i.getProductId());
            orderedItemsDTO.setQuantity(i.getQuantity());
            orderedItemsDTO.setTotalPrice(i.getTotalPrice());
            list.add(orderedItemsDTO);
        }
        orderDTO.setOrderDetailsDTOS(list);
        orderDTO.setOrderDate(order.getOrderDate());
        orderDTO.setBillTotal(order.getBillTotal());
        orderDTO.setDeliveryAddress(order.getDeliveryAddress());
        orderDTO.setDeliveryStatus(order.getDeliveryStatus());
        orderDTO.setUserId(order.getUserId());
        return orderDTO;
    }
}

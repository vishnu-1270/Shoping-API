package com.example.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Entity
@NoArgsConstructor
@AllArgsConstructor
public class OrderedItems {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int orderedItemsId;
    private int productId;
    private int price;
    private int quantity;
    private int totalPrice;

    @ManyToOne
    @JoinColumn(name="order_id")
    private Order order;
}

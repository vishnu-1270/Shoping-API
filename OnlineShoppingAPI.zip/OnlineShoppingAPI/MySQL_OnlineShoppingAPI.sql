select * from product;

select * from customer;
select * from address;

select * from cart;
select * from order_details;

select * from orders_table;
select * from ordered_items;

select * from admin_table;

select * from review;
use flipkart




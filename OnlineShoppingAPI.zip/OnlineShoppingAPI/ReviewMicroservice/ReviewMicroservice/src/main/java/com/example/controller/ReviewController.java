package com.example.controller;

import com.example.dto.ReviewDTO;
import com.example.dto.ShowReview;
import com.example.dto.UpdateReviewDTO;
import com.example.service.ReviewService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("review")
public class ReviewController {

    @Autowired
    private ReviewService reviewService;

    @PostMapping("addRatingAndReview")
    public ResponseEntity<ReviewDTO> addReview(@RequestBody ReviewDTO reviewDTO) {
        return new ResponseEntity<>(reviewService.addRatingAndReview(reviewDTO), HttpStatus.OK);
    }

    @PutMapping("updateReview")
    public ResponseEntity<ReviewDTO> updateReview(@RequestBody UpdateReviewDTO updateReviewDTO) {
        return new ResponseEntity<>(reviewService.updateReview(updateReviewDTO),HttpStatus.OK);
    }

    @GetMapping("getReviewsByProductId/{productId}")
    public ResponseEntity<List<ShowReview>> getReviews(@PathVariable int productId) {
        return new ResponseEntity<>(reviewService.getReviewsByProductId(productId),HttpStatus.OK);
    }

    @DeleteMapping("deleteReview/{reviewId}")
    public ResponseEntity<List<ShowReview>> deleteReview(@PathVariable int reviewId) {
        return new ResponseEntity<>(reviewService.deleteReview(reviewId),HttpStatus.OK);
    }
}

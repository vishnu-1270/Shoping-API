package com.example.service;

import com.example.dto.ReviewDTO;
import com.example.dto.ShowReview;
import com.example.dto.UpdateReviewDTO;
import com.example.entity.Review;
import com.example.repository.ReviewRepository;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.List;

@Service
@Transactional
public class ReviewService {

    @Autowired
    private ReviewRepository reviewRepository;

    @Autowired
    RestTemplate restTemplate;

    public ReviewDTO addRatingAndReview(ReviewDTO reviewDTO)
    {
        Review review=new Review();
        review.setReview(reviewDTO.getReview());
        review.setRating(reviewDTO.getRating());
        review.setOrderId(reviewDTO.getOrderId());
        review.setProductId(reviewDTO.getProductId());
        review.setUserId(reviewDTO.getUserId());
        reviewRepository.save(review);

        restTemplate.put("http://ProductMS/product/giveRating/"+reviewDTO.getProductId()+"/"+reviewDTO.getRating(),null);
        return reviewEntityToDTO(review);
    }

    public List<ShowReview> getReviewsByProductId(int productId)
    {
        List<Review> reviewList=reviewRepository.findAllByProductId(productId);
        List<ShowReview> showReviewList=new ArrayList<>();
        for (Review review:reviewList) {
            ShowReview showReview=new ShowReview();
            showReview.setReview(review.getReview());
            showReview.setRating(review.getRating());
            showReview.setUserId(review.getUserId());
            showReviewList.add(showReview);
        }
        return showReviewList;
    }

    public ReviewDTO updateReview(UpdateReviewDTO updateReviewDTO)
    {
        Review review=reviewRepository.findById(updateReviewDTO.getReviewId()).get();
        review.setReview(updateReviewDTO.getReview());
        return reviewEntityToDTO(review);
    }

    public List<ShowReview> deleteReview(int reviewId)
    {
        Review review=reviewRepository.findById(reviewId).get();
        int productId=review.getProductId();
        reviewRepository.delete(review);
        List<Review> reviewList=reviewRepository.findAllByProductId(productId);
        List<ShowReview> showReviewList=new ArrayList<>();
        for (Review i:reviewList) {
            ShowReview showReview=new ShowReview();
            showReview.setReview(i.getReview());
            showReview.setRating(i.getRating());
            showReview.setUserId(i.getUserId());
            showReviewList.add(showReview);
        }
        return showReviewList;
    }
    public ReviewDTO reviewEntityToDTO(Review review)
    {
        ReviewDTO reviewDTO=new ReviewDTO();
        reviewDTO.setReviewId(review.getReviewId());
        reviewDTO.setReview(review.getReview());
        reviewDTO.setRating(review.getRating());
        reviewDTO.setOrderId(review.getOrderId());
        reviewDTO.setProductId(review.getProductId());
        reviewDTO.setUserId(review.getUserId());
        return reviewDTO;
    }
}

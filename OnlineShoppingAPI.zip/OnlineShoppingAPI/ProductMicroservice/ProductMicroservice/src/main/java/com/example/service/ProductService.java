package com.example.service;

import com.example.dto.CategoriesDTO;
import com.example.dto.ProductDTO;
import com.example.enitity.Product;
import com.example.repository.ProductRepository;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

@Service
@Transactional
public class ProductService {

    @Autowired
    ProductRepository pr;

    public ProductDTO addProduct(ProductDTO productDTO)
    {
        if(productDTO.getDiscountToDate()!=null && productDTO.getDiscountFromDate()==null)
        {
            LocalDateTime t=LocalDateTime.now();
            productDTO.setDiscountFromDate(t);
        }
        productDTO.setRating(0);
        Product p=DtoToEntity(productDTO);
        pr.save(p);
        return EntityToDto(p);
    }

    public ProductDTO getProductById(int id)
    {
        Optional<Product> op=pr.findById(id);
        if(op.isPresent())
            return EntityToDto(op.get());
        return null;
    }

    public List<CategoriesDTO> getAllCategories()
    {
        List<String> categories=pr.findAllCategories();
        List<CategoriesDTO> categoriesDTOS=new ArrayList<>();
        for(String x:categories)
        {
            CategoriesDTO c=new CategoriesDTO();
            c.setCategories(x);
            categoriesDTOS.add(c);
        }
        return categoriesDTOS;
    }

    public List<ProductDTO> getProductsByCategory(String category)
    {
        List<Product> productList=pr.findAll();
        if(productList==null)
            return null;
        List<ProductDTO> productDTOList=productList.stream().filter(p->p.getCategory().equalsIgnoreCase(category)).map(p->EntityToDto(p)).collect(Collectors.toList());
        return productDTOList;
    }

    public List<ProductDTO> searchProduct(String search)
    {
        List<Product> product=pr.findAll();
        List<ProductDTO> dto=new ArrayList<>();
        String str=search.toLowerCase();
        for(Product x:product)
        {
            List<String> names=new ArrayList<>();

            String name=x.getName().toLowerCase();
            if(name.contains(" "))
                names.addAll(Arrays.asList(name.split(" ")));
            else names.add(name);

            String category=x.getCategory().toLowerCase();
            if(category.contains(" "))
                names.addAll(Arrays.asList(category.split(" ")));
            else names.add(category);

            for(String i:names)
            {
                if(str.contains(i))
                {
                    dto.add(EntityToDto(x));
                    break;
                }
            }

        }
        return dto;
    }

    public List<ProductDTO> searchProductPriceLowToHigh(String search)
    {
        List<ProductDTO> dto=searchProduct(search);
        dto=dto.stream().sorted((p1,p2)->p1.getPrice()-p2.getPrice()).collect(Collectors.toList());
        return dto;
    }

    public List<ProductDTO> searchProductPriceHighTolow(String search)
    {
        List<ProductDTO> dto=searchProduct(search);
        dto=dto.stream().sorted((p1,p2)->p2.getPrice()- p1.getPrice()).collect(Collectors.toList());
        return dto;
    }

    public List<ProductDTO> searchProductSortByRating(String search)
    {
        List<ProductDTO> dto=searchProduct(search);
        dto=dto.stream().sorted((p1,p2)->p2.getRating()- p1.getRating()).collect(Collectors.toList());
        return dto;
    }

    public List<ProductDTO> searchProductSortByAvailability(String search)
    {
        List<ProductDTO> dto=searchProduct(search);
        dto=dto.stream().sorted((p1,p2)->p2.getQuantity()-p1.getQuantity()).collect(Collectors.toList());
        return dto;
    }

    public List<ProductDTO> getAllProducts()
    {
        List<Product> products=pr.findAll();
        if(products.isEmpty())
            return null;
        List<ProductDTO> productDTO=new ArrayList<>();
        for(Product a:products)
        {
            productDTO.add(EntityToDto(a));
        }
        return productDTO;
    }

    public List<ProductDTO> searchProductSortByDiscount(String search)
    {
        List<ProductDTO> dto=searchProduct(search);
        LocalDateTime date=LocalDateTime.now();

        dto=dto.stream().filter(p-> date.isBefore(p.getDiscountToDate()) && p.getDiscount()>0).
        sorted((p1,p2)->p2.getDiscount()- p1.getDiscount()).collect(Collectors.toList());

        return dto;
    }

    public List<ProductDTO> getDiscountsForTheDay()
    {
        LocalDateTime date=LocalDateTime.now();
        List<Product> products=pr.findAll();

        List<ProductDTO> dto=products.stream().filter(p-> date.isAfter(p.getDiscountFromDate())&&date.isBefore(p.getDiscountToDate())&&p.getDiscount()>0).
        map(p->EntityToDto(p)).collect(Collectors.toList());

        return dto;
    }

    public ProductDTO updateProduct(int productId, ProductDTO dto)
    {
        Optional<Product> product=pr.findById(productId);
        if(product.isEmpty())
            return null;
        Product p=product.get();
        p.setName(dto.getName());
        p.setCategory(dto.getCategory());
        p.setDescription(dto.getDescription());
        p.setPrice(dto.getPrice());
        p.setQuantity(dto.getQuantity());
        p.setDiscount(dto.getDiscount());
        p.setDiscountFromDate(dto.getDiscountFromDate());
        p.setDiscountToDate(dto.getDiscountToDate());
        pr.save(p);
        return EntityToDto(p);
    }

    public ProductDTO productRating(int productId, int rating)
    {
        Optional<Product> op=pr.findById(productId);
        if(op.isEmpty())
            return null;
        Product p=op.get();
        if(p.getRating()==0)
            p.setRating(rating);
        else {
            double avg = (p.getRating() + rating) / 2;
            p.setRating((int) avg);
        }
        pr.save(p);
        return EntityToDto(p);
    }

    public List<ProductDTO> deleteProduct(int productId)
    {
        Optional<Product> product=pr.findById(productId);
        if(product.isEmpty())
            return null;
        pr.delete(product.get());

        List<Product> products=pr.findAll();
        List<ProductDTO> productsDTO=products.stream().map(p->EntityToDto(p)).collect(Collectors.toList());
        return productsDTO;
    }
    public Product DtoToEntity(ProductDTO dto)
    {
        Product p=new Product();
        p.setName(dto.getName());
        p.setCategory(dto.getCategory());
        p.setDescription(dto.getDescription());
        p.setPrice(dto.getPrice());
        p.setQuantity(dto.getQuantity());
        p.setRating(dto.getRating());
        p.setDiscount(dto.getDiscount());
        p.setDiscountFromDate(dto.getDiscountFromDate());
        p.setDiscountToDate(dto.getDiscountToDate());
        return p;
    }

    public ProductDTO EntityToDto(Product p)
    {
        ProductDTO dto=new ProductDTO();
        dto.setId(p.getId());
        dto.setName(p.getName());
        dto.setCategory(p.getCategory());
        dto.setDescription(p.getDescription());
        dto.setPrice(p.getPrice());
        dto.setQuantity(p.getQuantity());
        dto.setRating(p.getRating());
        dto.setDiscount(p.getDiscount());
        dto.setDiscountFromDate(p.getDiscountFromDate());
        dto.setDiscountToDate(p.getDiscountToDate());
        return dto;
    }
}

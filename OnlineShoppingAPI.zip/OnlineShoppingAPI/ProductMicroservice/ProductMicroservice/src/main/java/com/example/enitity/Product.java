package com.example.enitity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class Product {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "prod_id")
    private int id;

    @Column(name = "prod_name")
    private String name;
    private String category;

    @Column(name="prod_description")
    private String description;
    private int price;
    private int quantity;
    private int rating;
    private int discount;
    private LocalDateTime discountFromDate;
    private LocalDateTime discountToDate;

}

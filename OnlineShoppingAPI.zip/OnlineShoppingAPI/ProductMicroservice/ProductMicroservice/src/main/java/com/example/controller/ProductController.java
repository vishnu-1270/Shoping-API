package com.example.controller;

import com.example.dto.CategoriesDTO;
import com.example.dto.ProductDTO;
import com.example.enitity.Product;
import com.example.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("product")
public class ProductController {

    @Autowired
    ProductService ps;

    @PostMapping("addProduct")
    public ResponseEntity<ProductDTO> addProduct(@RequestBody ProductDTO product)
    {
        ProductDTO p=ps.addProduct(product);
        return new ResponseEntity<>(p, HttpStatus.OK);
    }

    @GetMapping("getProductById/{id}")
    public ResponseEntity<ProductDTO> getById(@PathVariable int id)
    {
        ProductDTO dto=ps.getProductById(id);
        if(dto!=null)
            return new ResponseEntity<>(dto,HttpStatus.OK);
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    @GetMapping("getAllProducts")
    public ResponseEntity<List<ProductDTO>> getAllProducts()
    {
        return new ResponseEntity<>(ps.getAllProducts(),HttpStatus.OK);
    }

    @GetMapping("getAllCategories")
    public ResponseEntity<List<CategoriesDTO>> getAllCategories()
    {
        return new ResponseEntity<>(ps.getAllCategories(),HttpStatus.OK);
    }

    @GetMapping("getProductsByCategory/{category}")
    public ResponseEntity<List<ProductDTO>> getProductsByCategory(@PathVariable String category)
    {
        List<ProductDTO> productDTOList=ps.getProductsByCategory(category);
        if(productDTOList==null)
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        return new ResponseEntity<>(productDTOList,HttpStatus.OK);
    }

    @GetMapping("searchProduct/{search}")
    public ResponseEntity<List<ProductDTO>> searchProduct(@PathVariable String search)
    {
        return new ResponseEntity<>(ps.searchProduct(search),HttpStatus.OK);
    }

    @GetMapping("searchProductPriceLowToHigh/{search}")
    public ResponseEntity<List<ProductDTO>> searchProductPriceLowToHigh(@PathVariable String search)
    {
        return new ResponseEntity<>(ps.searchProductPriceLowToHigh(search),HttpStatus.OK);
    }

    @GetMapping("searchProductPriceHighToLow/{search}")
    public ResponseEntity<List<ProductDTO>> searchProductPriceHighToLow(@PathVariable String search)
    {
        return new ResponseEntity<>(ps.searchProductPriceHighTolow(search),HttpStatus.OK);
    }

    @GetMapping("searchProductSortByRating/{search}")
    public ResponseEntity<List<ProductDTO>> searchProductSortByRating(@PathVariable String search)
    {
        return new ResponseEntity<>(ps.searchProductSortByRating(search),HttpStatus.OK);
    }

    @GetMapping("searchProductSortByAvailability/{search}")
    public ResponseEntity<List<ProductDTO>> searchProductSortByAvailability(@PathVariable String search)
    {
        return new ResponseEntity<>(ps.searchProductSortByAvailability(search),HttpStatus.OK);
    }

    @GetMapping("searchProductSortByDiscount/{search}")
    public ResponseEntity<List<ProductDTO>> searchProductSortByDiscount(@PathVariable String search)
    {
        return new ResponseEntity<>(ps.searchProductSortByDiscount(search),HttpStatus.OK);
    }

    @GetMapping("discountsForTheDay")
    public ResponseEntity<List<ProductDTO>> discountsForTheDay()
    {
        return new ResponseEntity<>(ps.getDiscountsForTheDay(),HttpStatus.OK);
    }

    @PutMapping("updateProduct/{productId}")
    public ResponseEntity<ProductDTO> updateProduct(@PathVariable int productId, @RequestBody ProductDTO dto)
    {
        ProductDTO p=ps.updateProduct(productId,dto);
        if(p==null)
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        return new ResponseEntity<>(p,HttpStatus.OK);
    }

    @PutMapping("giveRating/{productId}/{rating}")
    public ResponseEntity<ProductDTO> productRating(@PathVariable int productId, @PathVariable int rating)
    {
        ProductDTO dto=ps.productRating(productId,rating);
        if(dto==null)
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        return new ResponseEntity<>(dto,HttpStatus.OK);
    }

    @DeleteMapping("deleteProduct/{productId}")
    public ResponseEntity<List<ProductDTO>> deleteProduct(@PathVariable int productId)
    {
        List<ProductDTO> productDTOS=ps.deleteProduct(productId);
        if(productDTOS==null)
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        else
            return new ResponseEntity<>(productDTOS,HttpStatus.OK);
    }
}

package com.example.dto;

import lombok.Data;

@Data
public class AdminDTO {
    private int adminId;
    private String name;
    private String username;
    private String password;
    private String roles;
}

package com.example.dto;

import lombok.Data;

@Data
public class ShowReview {
    private int userId;
    private int rating;
    private String review;
}

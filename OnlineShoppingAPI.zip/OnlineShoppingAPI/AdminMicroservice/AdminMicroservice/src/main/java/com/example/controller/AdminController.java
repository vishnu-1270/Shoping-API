package com.example.controller;

import com.example.dto.*;
import com.example.service.AdminService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

@RestController
@RequestMapping("admin")
public class AdminController {

    @Autowired
    AdminService adminService;

    @Autowired
    RestTemplate restTemplate;

    static int adminId;

    @PostMapping("registerAdmin")
    public ResponseEntity<AdminDTO> registerAdmin(@RequestBody AdminDTO adminDTO) {
        return new ResponseEntity<>(adminService.addAdmin(adminDTO), HttpStatus.OK);
    }

    @PostMapping("loginAdmin")
    public ResponseEntity<String> login(@RequestBody LoginDTO loginDTO)
    {
        int result=adminService.login(loginDTO);
        if(result==0)
            return new ResponseEntity<>("Invalid login credentials",HttpStatus.NOT_FOUND);
        adminId=result;
        return new ResponseEntity<>("Login success.Your admin Id:"+adminId,HttpStatus.OK);
    }

    @PostMapping("addProduct")
    public ResponseEntity<ProductDTO> addProduct(@RequestBody ProductDTO productDTO) {
        ResponseEntity<ProductDTO> response = restTemplate.postForEntity("http://ProductMS/product/addProduct", productDTO, ProductDTO.class);
        return response;
    }

    @GetMapping("viewProductById/{id}")
    public ResponseEntity<ProductDTO> getProductById(@PathVariable int id) {
        ResponseEntity<ProductDTO> response = restTemplate.getForEntity("http://ProductMS/product/getProductById/" + id, ProductDTO.class);
        return response;
    }

    @GetMapping("getReviewsByProductId/{productId}")
    public ResponseEntity<List<ShowReview>> getReviews(@PathVariable int productId){
        ParameterizedTypeReference<List<ShowReview>> reference=new ParameterizedTypeReference<List<ShowReview>>() {
        };
        ResponseEntity<List<ShowReview>> response=restTemplate.exchange("http://ReviewMS/review/getReviewsByProductId/"+productId,HttpMethod.GET,null,reference);
        return response;
    }

    @GetMapping("viewAllProducts")
    public ResponseEntity<List<ProductDTO>> getAllProducts()
    {
        ProductDTO arr[]=restTemplate.getForObject("http://ProductMS/product/getAllProducts",ProductDTO[].class);
        List<ProductDTO> list= Arrays.asList(arr);
        return new ResponseEntity<>(list, HttpStatus.OK);
    }

    @GetMapping("viewAllCategories")
    public ResponseEntity<List<CategoriesDTO>> getAllCategories()
    {
        CategoriesDTO arr[]=restTemplate.getForObject("http://ProductMS/product/getAllCategories",CategoriesDTO[].class);
        List<CategoriesDTO> categoriesDTOS=Arrays.asList(arr);
        return new ResponseEntity<>(categoriesDTOS,HttpStatus.OK);
    }

    @PutMapping("updateProduct/{productId}")
    public ResponseEntity<ProductDTO> updateProduct(@RequestBody ProductDTO productDTO,@PathVariable int productId)
    {
        HttpHeaders headers=new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<ProductDTO> httpEntity=new HttpEntity<>(productDTO);
        ResponseEntity<ProductDTO> response= restTemplate.exchange("http://ProductMS/product/updateProduct/"+productId,HttpMethod.PUT,httpEntity,ProductDTO.class);
        return response;
    }

    @DeleteMapping("deleteProduct/{productID}")
    public ResponseEntity<List<ProductDTO>> deleteProduct(@PathVariable int productId)
    {
        ParameterizedTypeReference<List<ProductDTO>> responseType=new ParameterizedTypeReference<List<ProductDTO>>() {
        };
        ResponseEntity<List<ProductDTO>> response=restTemplate.exchange("http://ProductMS/product/deleteProduct/"+productId,HttpMethod.DELETE,null,responseType);
        return response;
    }

    @GetMapping("viewAllRegisteredCustomers")
    public ResponseEntity<List<CustomerDTO>> getAllCustomers()
    {
        ParameterizedTypeReference<List<CustomerDTO>> responseType=new ParameterizedTypeReference<List<CustomerDTO>>() {
        };
        ResponseEntity<List<CustomerDTO>> response=restTemplate.exchange("http://CustomerMS/customer/getAllCustomers",HttpMethod.GET,null,responseType);
        return response;
    }

    @GetMapping("viewSpecificCustomer/{customerId}")
    public ResponseEntity<CustomerDTO> getCustomerById(@PathVariable int customerId)
    {
        ResponseEntity<CustomerDTO> response=restTemplate.getForEntity("http://CustomerMS/customer/getCustomerById/"+customerId,CustomerDTO.class);
        return response;
    }

    @GetMapping("viewAllOrdersForSpecificCustomer/{customerId}")
    public ResponseEntity<List<OrderDTO>> getAllOrdersByCustomerId(@PathVariable int customerId)
    {
        ParameterizedTypeReference<List<OrderDTO>> responseType=new ParameterizedTypeReference<List<OrderDTO>>() {
        };
        ResponseEntity<List<OrderDTO>> response=restTemplate.exchange("http://OrderMS/order/viewAllOrdersForSpecificCustomer/"+customerId,HttpMethod.GET,null,responseType);
        return response;
    }

    @GetMapping("viewAllPlacedOrders")
    public ResponseEntity<List<OrderDTO>> viewAllOrders()
    {
        ParameterizedTypeReference<List<OrderDTO>> responseType=new ParameterizedTypeReference<List<OrderDTO>>() {
        };
        ResponseEntity<List<OrderDTO>> response=restTemplate.exchange("http://OrderMS/order/getAllPlacedOrders",HttpMethod.GET,null,responseType);
        return response;
    }

    @GetMapping("viewAllDeliveredOrders")
    public ResponseEntity<List<OrderDTO>> viewAllDelivered()
    {
        ParameterizedTypeReference<List<OrderDTO>> responseType=new ParameterizedTypeReference<List<OrderDTO>>() {
        };
        ResponseEntity<List<OrderDTO>> response=restTemplate.exchange("http://OrderMS/order/getAllDeliveredOrders",HttpMethod.GET,null,responseType);
        return response;
    }

    @GetMapping("viewOrderByOrderId/{orderId}")
    public ResponseEntity<OrderDTO> viewOrderById(@PathVariable int orderId)
    {
        ResponseEntity<OrderDTO> response=restTemplate.getForEntity("http://OrderMS/order/getOrderByOrderId/"+orderId,OrderDTO.class);
        return response;
    }

    @GetMapping("viewAllOrdersForSpecificDate/{date}")
    public ResponseEntity<List<OrderDTO>> viewOrdersForDate(@PathVariable LocalDate date)
    {
        ParameterizedTypeReference<List<OrderDTO>> responseType=new ParameterizedTypeReference<List<OrderDTO>>() {
        };
        ResponseEntity<List<OrderDTO>> response=restTemplate.exchange("http://OrderMS/order/viewAllOrdersForSpecificDate/"+date,HttpMethod.GET,null,responseType);
        return response;
    }

    @GetMapping("viewSaleForSpecificMonth/{month}")
    public ResponseEntity<MonthlySaleDTO> viewSaleByMonth(@PathVariable String month)
    {
        ResponseEntity<MonthlySaleDTO> response=restTemplate.getForEntity("http://OrderMS/order/viewSaleForSpecificMonth/"+month,MonthlySaleDTO.class);
        return response;
    }

    @PutMapping("updateDeliveryStatusForSpecificOrder/{orderId}/{status}")
    public ResponseEntity<OrderDTO> updateDeliveryStatus(@PathVariable int orderId, @PathVariable String status)
    {
        ResponseEntity<OrderDTO> response=restTemplate.exchange("http://OrderMS/order/updateDeliveryStatusForSpecificOrder/{orderId}/{status}",HttpMethod.PUT,null,OrderDTO.class,orderId,status);
        return response;
    }

    @GetMapping("logout")
    public ResponseEntity<String> logout()
    {
        adminId=0;
        return new ResponseEntity<>("Logged out",HttpStatus.OK);
    }
}

package com.example.service;

import com.example.dto.AdminDTO;
import com.example.dto.LoginDTO;
import com.example.entity.Admin;
import com.example.repository.AdminRepository;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
@Transactional
public class AdminService {

    @Autowired
    AdminRepository adminRepository;
    public AdminDTO addAdmin(AdminDTO adminDTO)
    {
        Admin admin=new Admin();
        admin.setName(adminDTO.getName());
        admin.setUsername(adminDTO.getUsername());
        admin.setPassword(adminDTO.getPassword());
        admin.setRoles(adminDTO.getRoles());
        adminRepository.save(admin);
        return adminEntityToDTO(admin);
    }

    public int login(LoginDTO loginDTO)
    {
        Optional<Admin> optional=adminRepository.findByUsernameAndPassword(loginDTO.getUsername(),loginDTO.getPassword());
        if(optional.isEmpty())
            return 0;
        return optional.get().getAdminId();
    }
    public AdminDTO adminEntityToDTO(Admin admin)
    {
        AdminDTO adminDTO=new AdminDTO();
        adminDTO.setAdminId(admin.getAdminId());
        adminDTO.setName(admin.getName());
        adminDTO.setUsername(admin.getUsername());
        adminDTO.setPassword(admin.getPassword());
        adminDTO.setRoles(admin.getRoles());
        return adminDTO;
    }
}

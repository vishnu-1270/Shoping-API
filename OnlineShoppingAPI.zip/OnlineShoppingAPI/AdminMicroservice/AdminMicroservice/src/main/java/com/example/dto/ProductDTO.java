package com.example.dto;

import lombok.Data;

import java.time.LocalDateTime;
@Data
public class ProductDTO {
    private int id;
    private String name;
    private String category;
    private String description;
    private int price;
    private int quantity;
    private int rating;
    private int discount;
    private LocalDateTime discountFromDate;
    private LocalDateTime discountToDate;
}

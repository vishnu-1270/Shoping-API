package com.example.dto;

import lombok.Data;

@Data
public class OrderedItemsDTO {
    private int productId;
    private int price;
    private int quantity;
    private int totalPrice;
}

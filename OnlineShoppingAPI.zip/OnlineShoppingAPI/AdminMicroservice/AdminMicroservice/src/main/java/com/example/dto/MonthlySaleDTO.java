package com.example.dto;

import lombok.Data;

@Data
public class MonthlySaleDTO {
    public String month;
    public int totalSale;
}
